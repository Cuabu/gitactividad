<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "gitactividad";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

$codigo_Consulta = $_POST['codigoConsulta']; 
$codigo_Consulta = $conn->real_escape_string($codigo_Consulta);

$sql = "SELECT * FROM productos WHERE codigo = '$codigo_Consulta'";
$result = $conn->query($sql);


if ($result->num_rows > 0) {
    // Mostrar los datos del producto
    while($row = $result->fetch_assoc()) {
        echo "Código: " . $row["codigo"]. "<br>";
        echo "Nombre: " . $row["nombre"]. "<br>";
        echo "Descripción: " . $row["descripcion"]. "<br>";
        echo "Precio: " . $row["precio"]. "<br>";
    }
} else {
    echo "No se encontró ningún producto con ese código.";
}
$conn->close();
?>
